# cafelora-zadani
Základ projektu pro Café Lóra
