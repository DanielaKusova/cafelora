import './index.html';
import './style.css';

console.log('funguju!');
